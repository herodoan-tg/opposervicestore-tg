# OPPO Experience & Service Store Tiền Giang — KPI & Approval Data Sync

Bộ dữ liệu chuẩn hóa từ file **`Tiền Giang - Tổng Hợp Sale V1.4 - T11.xlsx`** (kỳ báo cáo `01/11/2026 - 27/11/2026`), đóng gói sẵn để đẩy lên **GitHub** và đồng bộ trực tiếp với ứng dụng trên **Vercel (`vercel.app`)** theo luồng **duyệt phép (`approval_queue`)**.

## Cấu trúc thư mục

- `data/dashboard.json`: Tổng hợp KPI tháng, điểm theo nhóm hàng (`PHONE`, `TAI NGHE`, `PAD`, `ỐP LƯNG`, `Oppo Care`, `MDCL`, `Sạc dự phòng`, `WATCH`), năng suất kỹ thuật viên, tỷ lệ khách lẻ/đại lý, chỉ số TAT dịch vụ và tổng hợp doanh thu/điểm.
- `data/approvals.json`: Hàng đợi duyệt phiếu / bản ghi cần phê duyệt (`status`: `pending` / `approved` / `rejected`).
- `data/rules.json`: Bảng quy đổi điểm (`Model`, `Điểm tổng kết`, `Type`).
- `data/center_so.json` & `data/center_so.csv`: Dữ liệu bán hàng/xuất kho từ sheet `Center SO` (đã loại bỏ số điện thoại khách hàng để đảm bảo an toàn dữ liệu).
- `data/gcsm_so.json` & `data/gcsm_so.csv`: Dữ liệu phiếu dịch vụ/bán lẻ từ sheet `GCSM SO`.
- `api/health.js`: Endpoint kiểm tra trạng thái đồng bộ trên Vercel (`/api/health`).
- `vercel.json`: Cấu hình routing và header `no-cache` cho file JSON để Vercel luôn cập nhật dữ liệu mới nhất sau mỗi lần commit GitHub.
- `.gitignore`: Loại trừ file tạm/hệ thống khi đẩy lên GitHub.

## Quy trình đồng bộ GitHub -> Vercel

1. Giải nén file `.zip` vào thư mục dự án Git cục bộ.
2. Kiểm tra không có file thừa hoặc đường dẫn lồng nhau.
3. Chạy lệnh đẩy lên GitHub:
   ```bash
   git add .
   git commit -m "chore: sync T11 KPI and approval queue data"
   git push origin main
   ```
4. Vercel sẽ tự động build và cập nhật dữ liệu trên domain `.vercel.app`.
