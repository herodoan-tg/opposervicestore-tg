export default function handler(req, res) {
  res.status(200).json({
    status: "ok",
    store: "OPPO Experience & Service Store Tiền Giang",
    mode: "approval_queue",
    timestamp: new Date().toISOString()
  });
}
